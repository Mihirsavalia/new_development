"use client"

import React, { useState } from "react";
import BaseLayout from "../../components/BaseLayout";
import { Timepicker, Timepicker24Hr } from "next-ts-lib";
import "next-ts-lib/dist/index.css";

const TimepickerComponent: React.FC = () => {
    const [selected, setSelected] = useState<string>("");

    return (
        <BaseLayout>
            <h5 className="m-5 pt-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
                Time Picker
            </h5>
            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                    Basic
                </h2>
                <div className="pt-3 pl-7 mb-5 gap-8">
                    <Timepicker onChange={(value: string) => setSelected(value)} />
                </div>
            </div>

            <div className="p-2 m-3 bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                <h2 className="m-7 text-xl tracking-tight text-gray-900 dark:text-white">
                    Basic
                </h2>
                <div className="pt-3 pl-7 mb-5 gap-8">
                    <Timepicker24Hr onChange={(value: string) => setSelected(value)} />
                </div>
            </div>


        </BaseLayout>
    );
};

export default TimepickerComponent;
