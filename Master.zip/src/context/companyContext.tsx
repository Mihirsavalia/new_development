import React, { createContext, useContext, useState, ReactNode } from 'react';

interface CompanyContextProps {
    CompanyId: string;
    AccountingTools: number;
    setCompanyId: (value: string) => void;
    setAccountingTools: (value: number) => void;
}

const CompanyContext = createContext<CompanyContextProps | undefined>(undefined);

export const CompanyContextProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const [CompanyId, setInternalCompanyId] = useState<string>('Mihir');
    const [AccountingTools, setInternalAccountingTools] = useState<number>(13);

    const setCompanyId = (value: string) => {
        setInternalCompanyId(value);
    };

    const setAccountingTools = (value: number) => {
        setInternalAccountingTools(value);
    };

    return (
        <CompanyContext.Provider value={{ CompanyId, AccountingTools, setCompanyId, setAccountingTools, }}>
            {children}
        </CompanyContext.Provider>
    );
};

export const useCompanyContext = (): CompanyContextProps => {
    const context = useContext(CompanyContext);
    if (!context) {
        throw new Error('useCompany must be used within a CompanyProvider');
    }
    return context;
};
